"""Tipi di file gestiti dal Master (condiviso da server e client, nessuna dipendenza esterna).

Il Master puo' essere *qualsiasi* file: il server lo versiona sempre (revisioni, download, ripristino). Il tipo decide
solo come si fa il merge:

* ``l5x``    Rockwell XML (Studio 5000)   -> merge strutturale (Rung / Line / Tag ...)
* ``l5k``    Rockwell ASCII (RSLogix 5000) -> merge testuale per riga, con contesto Program/Routine
* ``plcopen`` PLCopen XML (TC6; export/import XML di CODESYS V3 e di altri IDE IEC 61131-3) -> merge strutturale
              (POU, DUT, variabili, righe ST/IL, configurazioni)
* ``text``   qualsiasi file di testo (es. ``.st``, ``.xml``, ``.project`` di altri IDE) -> merge testuale per riga
* ``binary`` qualsiasi altro file       -> solo versionamento: le richieste di merge non sono possibili
"""
from __future__ import annotations

import re
from pathlib import PurePath

L5X, L5K, PLCOPEN, TEXT, BINARY = "l5x", "l5k", "plcopen", "text", "binary"
KINDS = (L5X, L5K, PLCOPEN, TEXT, BINARY)

ROCKWELL_EXTS = (".L5K", ".L5X")             # K = export ASCII, X = export XML
MERGEABLE = (L5X, L5K, PLCOPEN, TEXT)

KIND_LABELS = {L5X: "Rockwell L5X (XML)", L5K: "Rockwell L5K (ASCII)", PLCOPEN: "PLCopen XML (CODESYS)",
               TEXT: "File di testo", BINARY: "File binario"}

_IE_VER = re.compile(rb"(?m)^\s*IE_VER\s*:=")
_L5K_CONTROLLER = re.compile(r"(?m)^\s*CONTROLLER\s+(\w+)\s*\(")
# radice <project> (anche con prefisso) nel namespace PLCopen TC6, come primo elemento del documento
_PLCOPEN_ROOT = re.compile(
    rb"\A(?:\xef\xbb\xbf)?\s*(?:<\?xml[^>]*\?>\s*)?(?:<!--.*?-->\s*)*"
    rb"(?:<!DOCTYPE(?:[^>\[]|\[.*?\])*>\s*)?"              # un DOCTYPE si riconosce per poterlo RIFIUTARE (XXE)
    rb"<(?:[\w.-]+:)?project(?=[\s>/])[^>]*?\sxmlns(?::[\w.-]+)?\s*=\s*[\"']http://www\.plcopen\.org/xml/tc6",
    re.S)
_HEAD = 8192


def detect_kind(data: bytes) -> str:
    """Riconosce il tipo dal *contenuto* (l'estensione da sola non basta: un .L5X puo' essere un file qualsiasi)."""
    head = data[:_HEAD]
    if b"RSLogix5000Content" in head[:4096]:
        return L5X
    if _IE_VER.search(head) and b"CONTROLLER" in data[:200_000]:
        return L5K
    if b"plcopen.org" in head and _PLCOPEN_ROOT.match(head):
        return PLCOPEN
    return BINARY if b"\x00" in data[:65536] else TEXT


def canonical_ext(filename: str, kind: str) -> str:
    """Estensione con cui il server salva il Master: ``.L5X`` / ``.L5K`` per i Rockwell, altrimenti quella del file."""
    if kind == L5X:
        return ".L5X"
    if kind == L5K:
        return ".L5K"
    ext = PurePath(filename or "").suffix
    ext = "".join(c for c in ext if c.isalnum() or c == ".")[:12]
    if len(ext) < 2:
        ext = ".xml" if kind == PLCOPEN else (".txt" if kind == TEXT else ".bin")
    return ext


def l5k_controller_name(data: bytes) -> str:
    m = _L5K_CONTROLLER.search(data[:200_000].decode("latin-1"))
    return m.group(1) if m else ""


def media_type(kind: str) -> str:
    return {L5X: "application/xml", PLCOPEN: "application/xml", L5K: "text/plain", TEXT: "text/plain"}.get(kind, "application/octet-stream")


PLCOPEN_FILTER = "PLCopen XML (*.xml *.XML)"


def compatible_kinds(master_kind: str, got: str) -> bool:
    """Un file di tipo ``got`` puo' essere proposto/reimportato su un Master di tipo ``master_kind``?

    Stesso tipo; in piu' i progetti di testo creati prima del riconoscimento di PLCopen XML (un ``.xml`` PLCopen era
    «File di testo») accettano ancora file che ora vengono riconosciuti come PLCopen.
    """
    return got == master_kind or (master_kind == TEXT and got == PLCOPEN)


def file_dialog_filters(ext: str = "", kind: str = "") -> str:
    """Filtri per ``QFileDialog``: il tipo del progetto per primo, poi Rockwell, poi *Tutti i file*."""
    out: list[str] = []
    if ext:
        out.append(f"File del progetto (*{ext.upper()} *{ext.lower()})")
    out.append("Rockwell (*.L5K *.L5X *.l5k *.l5x)")
    out.append(PLCOPEN_FILTER)
    out.append("Tutti i file (*)")
    return ";;".join(out)


def import_filters() -> str:
    """Filtri per scegliere il Master iniziale: tutti i file in testa, e Rockwell L5K/L5X a portata di mano."""
    return "Tutti i file (*);;Rockwell (*.L5K *.L5X *.l5k *.l5x);;Rockwell L5K (*.L5K *.l5k);;Rockwell L5X (*.L5X *.l5x);;" + PLCOPEN_FILTER


# ----------------------------------------------------------------------------- nome del file del Master
_BAD_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_REV_SUFFIX = re.compile(r"[ _-]*rev\d+$", re.I)
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}
DEFAULT_NAME = "Master"


def safe_stem(filename: str, fallback: str = DEFAULT_NAME) -> str:
    """Nome del file importato, senza estensione e senza caratteri vietati nei nomi file di Windows.

    Se il file si chiamava gia' ``Linea1_rev5.L5K`` il suffisso ``_rev5`` viene tolto: i file distribuiti ai client
    portano al massimo UN numero di revisione in fondo al nome (``Linea1_rev6.L5K``).
    """
    stem = PurePath((filename or "").replace("\\", "/")).stem
    stem = _BAD_CHARS.sub("_", stem).strip(" .")
    stem = _REV_SUFFIX.sub("", stem).strip(" ._-")
    if stem.upper() in _RESERVED:
        stem += "_"
    return stem[:120] or fallback


def rev_filename(name: str, revision: int, ext: str) -> str:
    """``<nome>_revN<ext>``: il nome del file importato con il numero di revisione in fondo."""
    return f"{name or DEFAULT_NAME}_rev{revision}{ext}"
